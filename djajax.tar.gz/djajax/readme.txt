Ce répertoire et environnment est destiné a effectuer un tutoriel  
de Django Ajax avec  une Bd Sqlite.
