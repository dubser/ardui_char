//Submit post on submit button
/* $('#post-form').on('submit', function(event){
   event.preventDefault();
   console.log("form submitted!")  // sanity check
   create_post();
}); */


/* //Submit post on enter key
$('form input').keydown(function (e) {
    if (e.keyCode == 13) {
        e.preventDefault();
        return false;
    }
}); */

//Submit post on input change
/* $("#post-text").change(function(event){
    console.log("Input focus out A")  // sanity check
    event.preventDefault();
    console.log("Input focus out B")  // sanity check
    create_post();
    console.log("Input focus out C")  // sanity check
}); */

//Submit post on enter in input field.
 $('#post-text').keypress(function(e) {
    if ( e.keyCode == 13 ) {  // detect the enter key
        e.preventDefault();
       console.log("Enter Key in field D")  // sanity check 
       send_back();
    }
}); 



// AJAX for posting
function send_back() {
    console.log("send_back is working!") // sanity check
    console.log($('#post-text').val())


    $.ajax({
        url : "send_back/", // the endpoint
        type : "POST", // http method
        data : { appel_no : "1", the_post : $('#post-text').val() }, // data sent with the post request

        // handle a successful response
        success : function(json) {
            $('#post-text').val(''); // remove the value from the input
            console.log(json); // log the returned json to the console
            console.log("json success"); // another sanity check
            $('#post-text').val('Allo ' +json["zpost_contenu"]+ ' Message #: '+
            json["Msg_no"]);
        },

        // handle a non-successful response
        error : function(xhr,errmsg,err) {
            $('#results').html("<div class='alert-box alert radius' data-alert>Oops! We have encountered an error: "+errmsg+
                " <a href='#' class='close'>&times;</a></div>"); // add the error to the dom
            console.log(xhr.status + ": " + xhr.responseText); // provide a bit more info about the error to the console
        }
    });

};
//=======================================================================================
// Ce code est standard pour un AJAX et ne doit pas etre touché.
// https://github.com/realpython/django-form-fun/blob/master/part1/main.js
//
//=======================================================================================

$(function() {


    // This function gets cookie with a given name
    function getCookie(name) {
        var cookieValue = null;
        if (document.cookie && document.cookie != '') {
            var cookies = document.cookie.split(';');
            for (var i = 0; i < cookies.length; i++) {
                var cookie = jQuery.trim(cookies[i]);
                // Does this cookie string begin with the name we want?
                if (cookie.substring(0, name.length + 1) == (name + '=')) {
                    cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                    break;
                }
            }
        }
        return cookieValue;
    }
    var csrftoken = getCookie('csrftoken');

    /*
    The functions below will create a header with csrftoken
    */

    function csrfSafeMethod(method) {
        // these HTTP methods do not require CSRF protection
        return (/^(GET|HEAD|OPTIONS|TRACE)$/.test(method));
    }
    function sameOrigin(url) {
        // test that a given url is a same-origin URL
        // url could be relative or scheme relative or absolute
        var host = document.location.host; // host + port
        var protocol = document.location.protocol;
        var sr_origin = '//' + host;
        var origin = protocol + sr_origin;
        // Allow absolute or scheme relative URLs to same origin
        return (url == origin || url.slice(0, origin.length + 1) == origin + '/') ||
            (url == sr_origin || url.slice(0, sr_origin.length + 1) == sr_origin + '/') ||
            // or any other URL that isn't scheme relative or absolute i.e relative.
            !(/^(\/\/|http:|https:).*/.test(url));
    }

    $.ajaxSetup({
        beforeSend: function(xhr, settings) {
            if (!csrfSafeMethod(settings.type) && sameOrigin(settings.url)) {
                // Send the token to same-origin, relative URLs only.
                // Send the token only if the method warrants CSRF protection
                // Using the CSRFToken value acquired earlier
                xhr.setRequestHeader("X-CSRFToken", csrftoken);
            }
        }
    });

});
